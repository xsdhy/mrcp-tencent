#!/bin/sh
#created by v_shiweiliu 2020-07-17
#MRCP Server stop script

curr_dir=$(dirname "$PWD")
process_name="unimrcpserver"
CRONTAB_BAK_FILE="./crontab.bak"


function clear_crontab(){
        echo 'Delete crontab task...'
        crontab -l > ${CRONTAB_BAK_FILE} 2>/dev/null
        sed -i '\#cd .*/admin/; ./start_server.sh#d' ${CRONTAB_BAK_FILE}
        crontab ${CRONTAB_BAK_FILE}
        rm ${CRONTAB_BAK_FILE}
        echo 'Delete crontab task Complete'

}

procnum=`ps -ef | grep ${process_name} | grep -v "grep" | awk '{print $2}' | wc -l`
if [ $procnum -ne 0 ]; 
then
    clear_crontab
    ps -ef | grep ${process_name} | grep -v "grep" | awk '{print $2}' | xargs kill
    echo "stoping MRCP Server..."
else
    echo "MRCP Server is not running!"
fi

sleep 1

procnum=`ps -ef | grep ${process_name} | grep -v "grep" | awk '{print $2}' | wc -l`
if [ $procnum -ne 0 ]; 
then
    clear_crontab
    ps -ef | grep ${process_name} | grep -v "grep" | awk '{print $2}' | xargs kill
fi

echo -e "\e[1;32mMRCP Server stop successfully!\e[0m"