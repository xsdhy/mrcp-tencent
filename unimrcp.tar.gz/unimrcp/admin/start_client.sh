#!/bin/sh
rootdir=$(dirname "$PWD")
echo "rootdir: ${rootdir}"
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:${rootdir}/lib
$rootdir/bin/unimrcpclient -r $rootdir 
